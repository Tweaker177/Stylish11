#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


static NSString *const kStylish11 = @"/var/mobile/Library/Preferences/com.i0stweak3r.stylish11.plist";
static NSMutableDictionary *settings;